// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "IconStyleSet.h"

#include "Interfaces/IPluginManager.h"
#include "Styling/SlateStyleRegistry.h"
#include "Styling/StyleColors.h"
#include "Styling/SlateStyleMacros.h"
#include "Interfaces/IPluginManager.h"

FName FIconStyleSet::StyleSetName = FName("Style");

TSharedPtr<FSlateStyleSet> FIconStyleSet::CreatedSlateStyleSet = nullptr;

void FIconStyleSet::InitializeIcons()
{
	if(!CreatedSlateStyleSet.IsValid())
	{
		CreatedSlateStyleSet = CreateSlateStyleSet();
	}
	/*Register*/
	FSlateStyleRegistry::RegisterSlateStyle(*CreatedSlateStyleSet);
}

void FIconStyleSet::ShutDownIcons()
{
	if(CreatedSlateStyleSet.IsValid())
	{
		/*Unregister*/
		FSlateStyleRegistry::UnRegisterSlateStyle(*CreatedSlateStyleSet);
		CreatedSlateStyleSet.Reset();
	}
}

#define RootToContentDir CustomStyleSet-> RootToContentDir

TSharedRef<FSlateStyleSet> FIconStyleSet::CreateSlateStyleSet()
{
	TSharedRef<FSlateStyleSet> CustomStyleSet = MakeShareable(new FSlateStyleSet(StyleSetName));

	const FString IconDirectory = 
	IPluginManager::Get().FindPlugin(TEXT("BPEditorGraphLock"))->GetBaseDir() /"Resources";
	
	CustomStyleSet->SetContentRoot(IconDirectory); 
	
	const FCheckBoxStyle CheckBoxStyle = FCheckBoxStyle()
	.SetCheckBoxType(ESlateCheckBoxType::CheckBox)
	/*Set three styles in the unchecked state*/
	.SetUncheckedImage(IMAGE_BRUSH("Lock",FVector2D(32.f),FStyleColors::White25))
	.SetUncheckedHoveredImage(IMAGE_BRUSH("Lock",FVector2D(32.f),FStyleColors::White))
	.SetUncheckedPressedImage(IMAGE_BRUSH("Lock",FVector2D(32.f),FStyleColors::AccentWhite))
	/*Set three styles in the checked state*/
	.SetCheckedImage(IMAGE_BRUSH("Unlock",FVector2D(32.f),FStyleColors::White25))
	.SetCheckedHoveredImage(IMAGE_BRUSH("Unlock",FVector2D(32.f),FStyleColors::White))
	.SetCheckedPressedImage(IMAGE_BRUSH("Unlock",FVector2D(32.f),FStyleColors::AccentWhite));
	
	CustomStyleSet->Set("IsGraphLocked",CheckBoxStyle);
	
	return CustomStyleSet;
}

#undef RootToContentDir