// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once

#include "Styling/SlateStyle.h"

/*This is a static library class used to register icons*/
class FIconStyleSet
{
public:
	/*Call Register*/
	static void InitializeIcons(); 

	/*Call Unregister*/
	static void ShutDownIcons();
	
	static TSharedRef<FSlateStyleSet> CreateSlateStyleSet();

	/*The name used to identity this style set*/
	static FName StyleSetName;

	/*Instance*/
	static TSharedPtr<FSlateStyleSet> CreatedSlateStyleSet;
	
};
